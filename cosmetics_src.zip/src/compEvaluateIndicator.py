#!/usr/local/bin/python
#encoding: gbk
#author: yanhaiming@baidu.com
#brief:calculate the precision and recall.

import sys

def loadBreedFile():
	

