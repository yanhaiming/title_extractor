import sys

def fun(str):
	print "calling fun..." + str
