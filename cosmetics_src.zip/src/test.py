# coding:utf8

print "中国"

